<?php
define('DB_SERVER', 'localhost');
define('DB_USER', 'pjm8632');
define('DB_PASS', 'Bully296');
define('DB_DATABASE', 'pjm8632');
?>